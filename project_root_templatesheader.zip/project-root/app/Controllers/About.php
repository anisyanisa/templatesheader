<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class About extends BaseController
{
    public function index()
    {
        // echo "Ini halaman About";
        $data['content']="Home Page Content";
        $data['title']='About';

        return view('templates/header',$data)
        .view('pages/about')
        .view('templates/footer');
    }
}
