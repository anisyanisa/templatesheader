<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Pages extends BaseController
{
    public function index()
    {
        //Script disini
        $data['content']="Home Page Content";
        $data['title']='Pages';

        return view('templates/header',$data)
        .view('pages/pages')
        .view('templates/footer');
    }
    
}
